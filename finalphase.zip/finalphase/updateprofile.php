<html>
</head>
<body>
<?php
session_start();
$name = $_SESSION['username'];
print_r($name);
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
try{
    $pdo = new PDO("mysql:host=localhost;dbname=matcha", "root", "123456");
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("ERROR: Could not connect. " . $e->getMessage());
}
 
// Attempt select query execution
try{
    if(isset($_POST['update'])){
        $sql = "UPDATE users SET firstname='$_POST[firstname]', lastname='$_POST[lastname]', username='$_POST[username]', email='$_POST[email]' WHERE username = '$username'";    
    $pdo->exec($sql);

    };
    $sql = "SELECT * FROM users ";   
    $result = $pdo->query($sql);
    if($result->rowCount() > 0){
        echo "<table>";
            echo "<tr>";
               
                echo "<th>firstname</th>";
                echo "<th>lastname</th>";
                echo "<th>username</th>";
                echo "<th>email</th>";
                // echo "<th>email</th>";
            echo "</tr>";
        while($row = $result->fetch()){
        echo "<form action=updateprofile.php method=post>";
            echo "<tr>";
                
                echo "<td>" . "<input type=text name=firstname value=" . $row['firstname'] . " </td>";
                echo "<td>" . "<input type=text name=lastname value=" . $row['lastname'] . " </td>";
                echo "<td>" . "<input type=text name=username value=" . $row['username'] . " </td>";
                echo "<td>" . "<input type=text name=email value=" .$row['email'] . " </td>";
                echo "<td>" . "<input type=submit name=update value=update" . " </td>";
            echo "</tr>";
        echo "</form>";
        }
        echo "</table>";
        // Free result set
        unset($result);
    } else{
        echo "No records matching your query were found.";
    }
} catch(PDOException $e){
    die("ERROR: Could not able to execute $sql. " . $e->getMessage());
}
 
// Close connection
unset($pdo);
?>

</body>
</html>